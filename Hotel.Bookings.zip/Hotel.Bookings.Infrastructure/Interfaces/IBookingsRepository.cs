﻿using HotelBookings.Application.Models;

namespace HotelBookings.Application.Interfaces
{
    public interface IBookingsRepository : IBaseRepository<Bookings>
    {
    }
}