﻿using HotelBookings.Application.Models;

namespace HotelBookings.Application.Interfaces
{
    public interface IHotelsRepository : IBaseRepository<Hotels>
    {
    }
}